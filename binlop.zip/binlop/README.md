# BiNLOP

**BiNLOP** (Bipolar Non‑linear Operator) is a high performance activation
function designed for modern deep learning architectures. It is a direct
descendant of the CMBIRU‑C activation described in the research literature,
renamed for clarity and packaged for immediate production use. BiNLOP
provides a tunable, invertible, multi‑scale rational activation with
provable Lipschitz properties. It is suitable for feed‑forward models,
transformers, invertible flows and any setting where smoothness and
stability are paramount.

This repository contains a reference implementation for both **PyTorch** and
**TensorFlow**, packaged as a lightweight library that can be installed via
`pip` and integrated into existing code with minimal effort. The core
implementation is framework‑agnostic and does not introduce hard
dependencies on either library. Optional extras pull in the desired
framework when needed.

## Features

- **Multi‑scale curvature:** BiNLOP blends multiple rational components to
  capture different activation regimes (small and large amplitudes) while
  remaining odd, smooth and strictly monotonic.
- **Certified Lipschitz bounds:** In its `standard_certified` mode the
  activation automatically clamps its adaptive gating to preserve a
  derivative band within `[m, 1]`, where `m` depends on the minimum tail
  slope. This prevents exploding or vanishing gradients without sacrificing
  expressivity.
- **Flow safe variant:** The `flow_safe` mode uses constant gating
  coefficients and exposes an exact, diagonal Jacobian suitable for
  normalising flow architectures and other reversible models.
- **Invertible:** BiNLOP admits a well‑conditioned inverse. An efficient
  Newton‑with‑bracketing routine is provided for recovering the input from
  the output (useful for memoryless backpropagation and reversible nets).
- **Optional adaptivity:** When adaptivity is not required the
  `standard_unconstrained` mode disables gating certification; this can be
  useful for ablation studies, although it forfeits Lipschitz guarantees.
- **Framework integration:** Native modules for PyTorch (`torch.nn.Module`)
  and TensorFlow (`tf.keras.layers.Layer`) are included. Custom autograd
  support in PyTorch allows for optional memoryless backward passes.

## Installation

Install the base package (no framework dependencies):

```bash
pip install binlop
```

To install with PyTorch support:

```bash
pip install "binlop[torch]"
```

To install with TensorFlow support:

```bash
pip install "binlop[tensorflow]"
```

BiNLOP has been tested with Python 3.8‑3.11 and recent versions of
PyTorch (≥ 1.10) and TensorFlow (≥ 2.10). It should work on both CPU and
GPU/TPU without modification. Mixed precision is supported internally by
accumulating critical operations in `float32`.

## Usage

### PyTorch

```python
import torch
from binlop.torch_binlop import Binlop

# Create a BiNLOP activation in standard certified mode
activation = Binlop(mode='standard_certified', k_inits=(1.5, 4.0))

# Use it in a model
class MyModel(torch.nn.Module):
    def __init__(self):
        super().__init__()
        self.linear1 = torch.nn.Linear(128, 128)
        self.act = activation
        self.linear2 = torch.nn.Linear(128, 10)

    def forward(self, x):
        x = self.linear1(x)
        x = self.act(x)
        x = self.linear2(x)
        return x

# Forward pass
x = torch.randn(32, 128)
out = MyModel()(x)

# Invert an activation output back to its input (flow safe or certified modes)
inv = activation.invert(out)

```

By default BiNLOP operates in the `standard_certified` mode, which ensures
strict Lipschitz guarantees when gating adaptivity is enabled. The
`flow_safe` mode uses constant mixture weights and is recommended for
normalising flows or when exporting static graphs.

### TensorFlow

```python
import tensorflow as tf
from binlop.tensorflow_binlop import Binlop

# Instantiate a BiNLOP layer
binlop = Binlop(mode='standard_certified', k_inits=(1.5, 4.0))

# Integrate into a Keras model
inputs = tf.keras.Input(shape=(128,))
x = tf.keras.layers.Dense(128)(inputs)
x = binlop(x)
outputs = tf.keras.layers.Dense(10)(x)
model = tf.keras.Model(inputs, outputs)

# Forward pass
out = model(tf.random.normal([32, 128]))

```

TensorFlow integration relies on the functional API and supports eager
execution. Due to the dynamic nature of the certified gating, custom
gradient logic is not provided; standard TensorFlow autodiff handles
backpropagation through the BiNLOP layer automatically.

## Modes

The `mode` argument controls how the mixture weights are computed:

- `'standard_certified'` (default): adaptively mixes multiple rational
  components based on an even context statistic while enforcing strict
  derivative bounds. Use this when you want both adaptivity and
  provable stability.
- `'flow_safe'`: uses constant mixture weights. This mode yields an
  exact diagonal Jacobian and is suitable for normalising flows,
  reversible networks, or exporting static graphs for inference.
- `'standard_unconstrained'`: adaptively mixes components without
  certification. This mode offers the maximum flexibility but does not
  guarantee that the derivative will remain within any particular
  bounds. It is primarily intended for ablation studies.

## License

This project is distributed under the terms of the MIT license. See the
`LICENSE` file for details.

## Contributing

Contributions are welcome! Please open an issue or pull request on the
GitHub repository if you find bugs or have suggestions for improvements.
